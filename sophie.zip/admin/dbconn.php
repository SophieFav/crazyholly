<?php
// if(isset($_SESSION['role'])&& $_SESSION['role']=='admin'){
$db = mysqli_connect("localhost", "favier.s", "ief774", "favier_db");
// }