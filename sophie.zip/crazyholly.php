<!DOCTYPE html>
<html>
<head>
  <title>Crazy Holly Art</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:700" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.wmin.js"></script>

  <link rel="stylesheet" href="css3-animate-it-master/css/animations.css" type="text/css">
  	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link href="lightbox/dist/css/lightbox.min.css" rel="stylesheet">


<?php
include("bootstrap.php");
?>

<style>
/*carousel*/
  
  #myBanner {
    width: 100%;
}

.banner, .head-banner,.crazyhollybanner{
	margin:0px;
	padding:0px;
	width:100%;
	height:100%;
	background-size: cover;
	background-position:center;
	background-repeat: no-repeat;
  }
  
  .banner{
	 background-image: url('img/banner.png');
  }


  </style>
</head>

<body>

<div class="diagonav fixed-top">
<img src="img/diagonav.png">
</div>

  
<!-- Navbar -->
<nav class="navbar navbar-expand-md bg navbar-dark fixed-top" id="myNavbar">
<div class="container">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php"> 
  <img src="img/crazyhollylogo3.png" onmouseover="this.src='img/crazyhollylogo3hover.png'" onmouseout="this.src='img/crazyhollylogo3.png'" style="width:150px">
  </a>

  <!-- Menu Hamburger -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Menu Liens -->
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
  <?php

$db = mysqli_connect("localhost","favier.s","ief774","favier_db");
$sql = "SELECT * FROM navigation ";
$result = mysqli_query($db, $sql);

while($data=mysqli_fetch_assoc($result)){
   $contenu = $data['navcontent'];
   echo $data['navcontent']; 
  }
  ?>
  
  <!--
    <ul class="navbar-nav">
		<li class="nav-item">
		  <a class="nav-link" href="#home">Home</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" href="#portfolio">Portfolio</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" href="#about">About</a>
		</li>
		<li class="nav-item">
		  <a class="nav-link" href="#contact">Contact</a>
		</li>
    </ul>
   --> 
   </div>
  </div>
</nav>
<!-- Banner -->
<div id="home" class="container-fluid banner bg header">
	<div id="myBanner">
	  <div class="head-banner">
		<div class="crazyhollybanner">
		</div>
	 </div>
	</div>
</div>
  <!-- End Banner -->
  
<!-- Portfolio -->
<div id="portfolio" class="bg">
    <div class="container">
        <div class="row about">

<div class="col-lg-12 artwork">
			<h1>ARTWORK</h1>
    	</div>
</div>	
<div id="imageviewer" class="row">
	
	</div>
	
<script>
$(document).ready(function(){
	load_data();
	function load_data(page){
	$.ajax({
		url: "showmore.php",
		method: "POST",
		data:{page:page},
		success:function(data){
			$("#imageviewer").append(data);
		}
	})
	}
	   $(document).on('click', '.page-link', function(){  
           var page = $(this).attr("id");  
           $(this).hide();
           load_data(page);  
      });  
});
</script>
</div>

<div class="container">
<ul class="pagination justify-content-center">

<?php
//création de la barre de pagination
// if($imagepage>1){
	// echo "<li class='page-item'>";
// }else{
	// echo "<li class='page-item disabled'>";
// }
	// echo "<a class='page-link' href='crazyholly.php?imagepage=".($imagepage-1)."#section2'>Previous</a>";

	// echo "</li>";
// for($i=1; $i<=$pagination; $i++){
	// if($i==$imagepage){
	// echo "<li class='page-item active'>";
	// }else{
		// echo "<li class='page-item'>";
		// }
	// echo "<a class='page-link' href='crazyholly.php?imagepage=".$i."#section2'>".$i."</a>";
	// echo "</li>";
 // } 
 // if($imagepage==$pagination){
	// echo "<li class='page-item disabled'>";
 // }else{
	// echo "<li class='page-item'>";
 // }
	// echo "<a class='page-link' href='crazyholly.php?imagepage=".($imagepage+1)."#section2'>Next</a>";
	// echo "</li>";
// ?>
</ul>
</div>
</div>
</div>
<!-- End Portfolio -->

<!-- about -->
<div id="about" class="container-fluid bg">
<div class="container">

<?php

	
		$db = mysqli_connect("localhost","favier.s","ief774","favier_db");
		$sql= "SELECT * FROM sections WHERE sectionname='about'";
		$result=mysqli_query($db,$sql);
			if($data=mysqli_fetch_assoc($result)){
				echo $data['sectioncontent'];	
			}else{
				echo "sorry, this section isn't exist";	
			}
		mysqli_close($db);

?>

 <!--<h2 class="about">About Me</h2>-->
<!--<div class="row about">

<div class="col-lg-12 aboutme">
			<h1>ABOUT</h1>
</div>
<div class="row whatdoido">

    	<div class="col-sm-3 whati">
    	<h4 class="title"> Who I Am </h4> 

  
			<p>I'm Sophie, I come from Belgium.
			I create digital collages.
			I love 50s for old movies, the Cinematographic Aesthetics, the pretty pin-ups, 
			the hand-painted Movie posters, the old magazines and old advertisings...
			I also love the horror's world. 
			That's why I wanted to create artworks with these two universes
			together.</p>
    	</div>

    	
    	<div class="col-sm-3 whati">
	     <h4 class="title"> what I watch </h4>    


			<p>I like watching old movies, such as Hitchcock and Hawks movies,
			Horror movies with serial killers, ghosts and demons, TV shows like American Horror Story, 
			Mad Men, Nip-Tuck, Penny Dreadful, Mindhunter, Bates Motel, Game Of Thrones ...</p>
    	</div> 
    	
    	<div class="col-sm-3 whati">
	     <h4 class="title"> what I listen </h4>


			<p>my musical tastes are quite varied, I like listening to classical like Tchaikovsky, 
			retro singers like Julie London ,electro like Justice ,old rock like The Doors and The Cramps, rock metal like Rob Zombie, hip-hop like Al'tarba  ...</p>
    	
    	</div>
    	    	<div class="col-sm-3 whati">
	     <h4 class="title"> what else </h4>


	<p>I collect old magazines dating from 1900 to 1980, books talking about the cinema of the 20s and 50s and the "Hey ! Modern art & pop culture" books.</p>
    
    </div>
  
    	</div>
    </div>-->
    </div>
</div>
<!-- End about -->

<!-- contact -->
<div id="contact" class="container-fluid bg">
  <!--<h2 class="contact">Contact me</h1>-->
  <div class="container form">

      <div class="row">                
          <div class="col-lg-3 logoch">
              <img src ="img/logoshadow.png">
          </div>  
          <div class="col-lg-6">
            <form class='col-lg-12' method="post" action="mail.php" onsubmit="sendmail();return false;">
            <h4 class="title">Contact Me</h4>
                <div class="form-group">
                  <!--<label for="email">Email address:</label>-->
                  <input type="email" placeholder="ex: name@example.com" class="form-control" id="email"  style="border-radius:0px;">
                </div>
              <div class="form-group">
                <!--<label for="comment">Comment:</label>-->
                <textarea class="form-control" rows="3" id="message"  style="border-radius:0px;"></textarea>
              </div>
            <button type="submit" class="btn" style="border-radius:0px;" >Submit</button>
            <div id="ackmsg" class="col-8"></div>
          </form>
         </div>
         <script>

function sendmail(){
$("#submit-btn").attr("disabled", "disabled");
//$("#ackmsg").php("<img src='img/loading.gif' style='width:40px;'>");

var email = $("#email").val();
var message = $("#message").val();
$.ajax({
	
                    type : "POST",
                    url: "mail.php",
                    data: '&email='+email+'&message='+message,
                    success: function(reponse) {
                    	console.log(reponse);
                    	if(reponse=="ok"){
                    		//$("#ackmsg").html("<span style='color:green'>Votre email a bien été envoyé</span>");
							$("#email").val("");
							$("#message").val("");
							$("#submit-btn").removeAttr("disabled", "disabled");
                    	}
                    },
                    error: function() {
                        //$("#ackmsg").html(reponse);
                      header("Location: http://favier.addesign.be/crazyholly.php#section4");	
                      unset($_POST);
                    }
                });
}
</script>
          <div class="col-lg-3 hollyis">
              <h4 class="title">Holly is...</h4>
              <p class="text">#Crazy #Dirty #Bloody #Sexy<p>
          <h4 class="title">Follow Me</h4>
              <ul class=" socialnetwork">
                  <li><a href="http://www.instagram.com/crazy.holly.art/" target="_blank" ><img src='img/instalogo2.png'/></a></li>
                  <li><a href="http://www.crazy-holly.tumblr.com/" target="_blank" ><img src='img/tumblrlogo2.png'/></a></li>
                  <li><a href="https://www.pinterest.com/crazyh0lly/" target="_blank" ><img src='img/pinlogo2.png'/></a></li>
              </ul>   

              </div> 
              </div>

</div>

</div>
<div class='container-fluid copy'>
<div class="diagofooter fixed-bottom">
<p class='copyright fixed-bottom'>Copyright &copy Crazy Holly Art 2018</p>
<img src="img/diagofooter.png">
</div>
</div>

<script src='css3-animate-it-master/js/css3-animate-it.js'></script>
<script src="lightbox/dist/js/lightbox.min.js"></script>
<script src='scrollspy.js'></script>
</body>
</html>

